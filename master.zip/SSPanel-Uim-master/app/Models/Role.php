<?php

namespace App\Models;

/**
 * Node Model
 */
class Role extends Model
{
    protected $connection = 'default';
    protected $table = 'user_role';
}
